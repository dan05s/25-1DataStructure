#include "Calculator.h"

//Entry point of the program
int main() {
    Calculator cal;//Create a Calculator object
    cal.run();//Start the calculator
    return 0;//Exit program
}